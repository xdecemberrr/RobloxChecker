# -RobloxChecker-
Whipped This Boy Up (Bored...)


Just put your list of names in the `names.txt` file.

And run that bad boy

requirements: `requests` & `colorama`

# PS:
  Made using Windows, So Built For Windows. Uhh python 3.8 ^
